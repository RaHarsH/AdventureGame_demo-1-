import pygame
from support import import_folder

class ParticleEffect(pygame.sprite.Sprite):
    def __init__(self, pos, type):
        super().__init__()
        self.frame_index = 0
        self.animation_speed = 0.5
        if type == 'jump':
            self.frames = import_folder('../PyAdventureGame1/graphics/character/dust_particles/jump')

        if type == 'land':
            self.frames = import_folder('../PyAdventureGame1/graphics/character/dust_particles/land') 
        self.image = self.frames[self.frame_index]               
        self.rect = self.image.get_rect(center = pos)

    def animate(self):
        self.frame_index += self.animation_speed
        if self.frame_index >= len(self.frames):
            # if frame index exceedes the length  then we are removing it
            # cuz we have to trigger the jump dust particle only while jumping so iterating it over and over again is not required
            self.kill()

        else:
            self.image = self.frames[int(self.frame_index)]    #its a tuple o we are converting it to int

    def update(self, x_shift):       
        self.animate()
        self.rect.x += x_shift